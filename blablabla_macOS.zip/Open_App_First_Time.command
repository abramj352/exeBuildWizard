#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
xattr -cr "$DIR/blablabla.app"
open "$DIR/blablabla.app"
