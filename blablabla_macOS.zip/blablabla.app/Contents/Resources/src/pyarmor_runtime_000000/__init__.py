# Pyarmor 9.2.5 (trial), 000000, 2026-09-09T18:21:36.250902
from .pyarmor_runtime import __pyarmor__
